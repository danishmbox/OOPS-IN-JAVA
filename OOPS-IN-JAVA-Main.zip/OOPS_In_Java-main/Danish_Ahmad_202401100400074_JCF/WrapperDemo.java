import java.util.*;
public class WrapperDemo {
    public static void main(String args[]){
        ArrayList<Integer> lst=new ArrayList<>();
        lst.add(10);
    }
}